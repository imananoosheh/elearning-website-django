from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
# Import necessary classes
from django.http import HttpResponse, Http404
from .models import Topic, Course, Student, Order
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from .forms import SearchForm, OrderForm, ReviewForm


# Create your views here.

def index(request):
    top_list = Topic.objects.all().order_by('id')[:10]
    return render(request, 'myapp/index.html', {'top_list': top_list})


def about(request):
    response = HttpResponse()
    about_message = 'This is an E-learning Website! Search our Topics to find all available Courses.'
    return render(request, 'myapp/about.html', {'about_message': about_message})


def detail(request, topic_id):
    topic = get_object_or_404(Topic, pk=topic_id)
    related_courses = Course.objects.filter(topic=topic_id)
    return render(request, 'myapp/detail.html',
                  {'topic_id': topic_id, 'topic': topic, 'related_courses': related_courses})


def findcourses(request):
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            length = form.cleaned_data['length']
            max_price = form.cleaned_data['max_price']
            if length:
                topics = Topic.objects.filter(length=length)
            else:
                topics = Topic.objects.all()
            courselist = []
            for top in topics:
                for course in list(top.courses.all()):

                    if course.price <= max_price:
                        courselist.append(str(course.title))

            return render(request, 'myapp/results.html', {'courselist': courselist, 'name': name, 'length': length, 'max_price' : max_price})
        else:
            return HttpResponse('Invalid data')
    else:
        form = SearchForm()
        return render(request, 'myapp/findcourses.html', {'form': form})

def place_order(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            courses = form.cleaned_data['courses']
            order = form.save(commit=False)
            student = order.student
            status = order.order_status
            order.save()
            if status == 1:
                for c in courses.all():
                    student.registered_courses.add(c)
            return render(request, 'myapp/order_response.html', {'courses': courses, 'order': order})
        else:
            return render(request, 'myapp/place_order.html', {'form': form})

    else:
        form = OrderForm()
        return render(request, 'myapp/place_order.html', {'form': form})

def review_view(request):
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=True)
            rating = form.cleaned_data['rating']
            course = form.cleaned_data['course']
            review.save()

            if 1 <= rating <= 5:
                course.num_reviews += 1
                course.save()
                top_list = Topic.objects.all().order_by('id')
                error_message = 'Thank you for reviewing the course: ' + str(course.title) + '!'
                return render(request, 'myapp/review.html', {'form': form, 'error_message': error_message})
            else:
                form = ReviewForm()
                error_message = 'You must enter a rating between 1 and 5!'
                return render(request, 'myapp/review.html', {'form': form, 'error_message': error_message})
    else:
        form = ReviewForm()
        return render(request, 'myapp/review.html', {'form': form})