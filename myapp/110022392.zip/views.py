from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
# Import necessary classes
from django.http import HttpResponse, Http404
from .models import Topic, Course, Student, Order
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from .forms import SearchForm


# Create your views here.

def index(request):
    top_list = Topic.objects.all().order_by('id')[:10]
    return render(request, 'myapp/index.html', {'top_list': top_list})


def about(request):
    response = HttpResponse()
    about_message = 'This is an E-learning Website! Search our Topics to find all available Courses.'
    return render(request, 'myapp/about.html', {'about_message': about_message})


def detail(request, topic_id):
    topic = get_object_or_404(Topic, pk=topic_id)
    related_courses = Course.objects.filter(topic=topic_id)
    return render(request, 'myapp/detail.html',
                  {'topic_id': topic_id, 'topic': topic, 'related_courses': related_courses})


def findcourses(request):
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            length = form.cleaned_data['length']
            max_price = form.cleaned_data['max_price']
            if length:
                topics = Topic.objects.filter(length=length)
            else:
                topics = Topic.objects.all()
            courselist = []
            for top in topics:
                for course in list(top.courses.all()):

                    if course.price <= max_price:
                        courselist.append(str(course.title))

            return render(request, 'myapp/results.html', {'courselist': courselist, 'name': name, 'length': length, 'max_price' : max_price})
        else:
            return HttpResponse('Invalid data')
    else:
        form = SearchForm()
        return render(request, 'myapp/findcourses.html', {'form': form})
